create database projectss
use projectss

create table canidate(CNIC INT , rollno int)
-- Create the Questions table


CREATE TABLE IntQuestions (
    Id INT PRIMARY KEY,
    QuestionText VARCHAR(MAX),
    Option1 VARCHAR(MAX),
    Option2 VARCHAR(MAX),
    Option3 VARCHAR(MAX),
    Option4 VARCHAR(MAX),
    CorrectAnswer VARCHAR(MAX)
);

select * from AccQuestions

CREATE TABLE AccQuestions (
    Id INT PRIMARY KEY,
    QuestionText VARCHAR(MAX),
    Option1 VARCHAR(MAX),
    Option2 VARCHAR(MAX),
    Option3 VARCHAR(MAX),
    Option4 VARCHAR(MAX),
    CorrectAnswer VARCHAR(MAX)
);
-- Insert sample questions
INSERT INTO IntQuestions (Id, QuestionText, Option1, Option2, Option3, Option4, CorrectAnswer)
VALUES
    (1, 'What is the capital of Pakistan?', 'Karachi', 'Lahore', 'Islamabad', 'Quetta', 'Islamabad'),
    (2, 'Who is the founder of Pakistan?', 'Allama Iqbal', 'Quaid-e-Azam Muhammad Ali Jinnah', 'Liaquat Ali Khan', 'Sir Syed Ahmed Khan', 'Quaid-e-Azam Muhammad Ali Jinnah'),
    (3, 'Which mountain range is located in Pakistan?', 'Himalayas', 'Andes', 'Karakoram', 'Alps', 'Karakoram'),
    (4, 'Which river is the longest in Pakistan?', 'Chenab', 'Indus', 'Ravi', 'Sutlej', 'Indus'),
    (5, 'What is the national flower of Pakistan?', 'Jasmine', 'Rose', 'Tulip', 'Sunflower', 'Jasmine');

-- Insert academic questions

INSERT INTO AccQuestions (Id, QuestionText, Option1, Option2, Option3, Option4, CorrectAnswer)
VALUES
    (1, 'What is the formula for calculating the area of a rectangle?', 'Length * Width', '2 * (Length + Width)', 'Length * Height', '(Length + Width) / 2', 'Length * Width'),
    (2, 'Who discovered the theory of relativity?', 'Isaac Newton', 'Albert Einstein', 'Galileo Galilei', 'Stephen Hawking', 'Albert Einstein'),
    (3, 'What is the chemical symbol for water?', 'H2O', 'CO2', 'NaCl', 'O2', 'H2O'),
    (4, 'Which planet is known as the "Red Planet"?', 'Venus', 'Mars', 'Jupiter', 'Saturn', 'Mars'),
    (5, 'What is the powerhouse of the cell?', 'Nucleus', 'Mitochondria', 'Ribosome', 'Endoplasmic reticulum', 'Mitochondria');

