﻿using BusinessLogicLayer;
using System;
using System.Web.UI;

namespace sampletest
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        private bll bLogic;
        private string[] questions,Option1,Option2,Option3,Option4;
        private int currentQuestionIndex;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                bLogic = new bll();
                questions = bLogic.GetQuestions().ToArray();
                Option1 = bLogic.GetGetOption1().ToArray();
                Option2 = bLogic.GetGetOption2().ToArray();
                Option3 = bLogic.GetGetOption3().ToArray();
                Option4 = bLogic.GetGetOption4().ToArray();
                ViewState["questions"] = questions; // Store questions in ViewState
                ViewState["Option1"] = Option1;
                ViewState["Option2"] = Option2;
                ViewState["Option3"] = Option3;
                ViewState["Option4"] = Option4;
                ViewState["currentQuestionIndex"] = 0; // Store current question index in ViewState
                DisplayCurrentQuestion();
                
            }
            else
            {
                questions = (string[])ViewState["questions"]; // Retrieve questions from ViewState
                Option1 = (string[])ViewState["Option1"];
                Option2 = (string[])ViewState["Option2"];
                Option3 = (string[])ViewState["Option3"];
                Option4 = (string[])ViewState["Option4"];
                currentQuestionIndex = (int)ViewState["currentQuestionIndex"]; // Retrieve current question index from ViewState
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            currentQuestionIndex++;
            if (currentQuestionIndex < questions.Length)
            {
                ViewState["currentQuestionIndex"] = currentQuestionIndex; // Update ViewState with new index
                DisplayCurrentQuestion();
                Count.Text = currentQuestionIndex.ToString();
            }
            else
            {
                Label1.Text = "End of questions.";
                
                RadioButton1.Text = "None";
                RadioButton2.Text = "None";
                RadioButton3.Text = "None";
                RadioButton4.Text = "None";
                Button1.Enabled = false; // Disable the button when all questions are displayed
            }
        }

        private void DisplayCurrentQuestion()
        {
            Label1.Text = questions[currentQuestionIndex];
            RadioButton1.Text = Option1[currentQuestionIndex];
            RadioButton2.Text = Option2[currentQuestionIndex];
            RadioButton3.Text = Option3[currentQuestionIndex];
            RadioButton4.Text = Option4[currentQuestionIndex];
            //RadioButton1.Checked = false;
            //RadioButton2.Checked = false;
            //RadioButton3.Checked = false;
            //RadioButton4.Checked = false;
        }

        protected void RadioButton1_CheckedChanged(object sender, EventArgs e)
        {
            // Add logic to handle radio button selection if needed
        }

        protected void RadioButton2_CheckedChanged(object sender, EventArgs e)
        {
            // Add logic to handle radio button selection if needed
        }

        protected void RadioButton3_CheckedChanged(object sender, EventArgs e)
        {
            // Add logic to handle radio button selection if needed
        }

        protected void RadioButton4_CheckedChanged(object sender, EventArgs e)
        {
            // Add logic to handle radio button selection if needed
        }
    }
}
